package com.employeeManagement.service;

import java.util.Date;
import java.util.List;

import com.employeeManagement.entity.Employee;

public interface EmployeeServiceInterface {

	Employee addEmployee(Employee employee);

	List<Employee> getAllEmployees();

	Employee getEmployeeById(Long empId);

	void deleteEmployeeById(Long empId);

	Employee updateEmployee(Long empId, Employee employee);

	List<Employee> getEmployeeByFirstName(String firstName);

	List<Employee> getEmployeeByLastName(String lastName);

	List<Employee> getEmployeeByPhone(Long phone);

	List<Employee> getEmployeeByEmail(String email);
	
//	Employee updateEmployee(String firstName, String lastName, Date dateOfBirth,String email,Long phone, String photoPath, Long empId);
}
