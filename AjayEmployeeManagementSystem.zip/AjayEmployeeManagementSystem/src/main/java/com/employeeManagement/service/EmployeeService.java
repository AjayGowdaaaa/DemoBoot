package com.employeeManagement.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.employeeManagement.custom.exception.BusinessException;
import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;

@Service
public class EmployeeService implements EmployeeServiceInterface {

	private final Logger logger = LoggerFactory.getLogger(EmployeeService .class);

	@Autowired
	private EmployeeRepository employeeRepository;



	//---------------------ADD EMPLOYEE-----------------------------------------------------	
	@Override

	public Employee addEmployee(MultipartFile file ,Employee employee) {
		Employee  savedEmployee = employee;

		if (!(employeeRepository.findByPhone(savedEmployee.getPhone())==null) ) {

			throw new BusinessException("AddEmployee Duplicate Phone","Entered Phone Number already exsists in DataBase");
		}
		if (!(employeeRepository.findByEmail(savedEmployee.getEmail())==null) ) {
			throw new BusinessException("AddEmployee Duplicate Email","Entered Email Id already exsists in DataBase");
		}

		if ((employeeRepository.findByPhone(savedEmployee.getPhone())==null && 
				employeeRepository.findByEmail(savedEmployee.getEmail())==null)) {
			try {
				String fileName = "";
				
				Employee savingEmployee = new Employee(fileName, file.getContentType(), file.getBytes());
				
				savingEmployee.setFirstName(employee.getFirstName());
				savingEmployee.setLastName(employee.getLastName());
				savingEmployee.setEmail(employee.getEmail());
				savingEmployee.setDateOfBirth(employee.getDateOfBirth());
				savingEmployee.setPhone(employee.getPhone());

				employee= employeeRepository.save(savingEmployee);
				savingEmployee.setESTUATE_ID("EST-"+employee.getEmpId());
				savingEmployee.setFileName(employee.getESTUATE_ID()+" "+employee.getFirstName());
				
				return employeeRepository.save(savingEmployee);
				
			} catch (IllegalArgumentException e) {
				throw new BusinessException("EmployeeService-addEmployee-2",
						"Not Valid Name, Please Enter Valid Name " + e.getMessage());
			} catch (Exception e) {
				throw new BusinessException("EmployeeService-addEmployee-3",
						"Something went wrong in service layer " + e.getMessage());
			}
		}else {
			throw new BusinessException("EmployeeService-addEmployee-1;",
					"Email Id or Mobile Already Exsists in DataBase ")	;
		}

	}



	//	@Override
	//
	//	public Employee addEmployee(Employee employee) {
	//		Employee  savedEmployee = employee;
	//
	//		if (!(employeeRepository.findByPhone(savedEmployee.getPhone())==null) ) {
	//			
	//			throw new BusinessException("AddEmployee Duplicate Phone","Entered Phone Number already exsists in DataBase");
	//		}
	//		if (!(employeeRepository.findByEmail(savedEmployee.getEmail())==null) ) {
	//			throw new BusinessException("AddEmployee Duplicate Email","Entered Email Id already exsists in DataBase");
	//		}
	//
	//		if ((employeeRepository.findByPhone(savedEmployee.getPhone())==null && 
	//				employeeRepository.findByEmail(savedEmployee.getEmail())==null)) {
	//			try {
	//				// Try to do this in transaction-------------------------------------------------
	//				savedEmployee = employeeRepository.save(employee);		
	//				savedEmployee.setESTUATE_ID("EST-"+savedEmployee.getEmpId());
	//				savedEmployee = employeeRepository.save(employee);
	//				return savedEmployee;
	//			} catch (IllegalArgumentException e) {
	//				throw new BusinessException("EmployeeService-addEmployee-2",
	//						"Not Valid Name, Please Enter Valid Name " + e.getMessage());
	//			} catch (Exception e) {
	//				throw new BusinessException("EmployeeService-addEmployee-3",
	//						"Something went wrong in service layer " + e.getMessage());
	//			}
	//		}else {
	//			throw new BusinessException("EmployeeService-addEmployee-1;",
	//					"Email Id or Mobile Already Exsists in DataBase ")	;
	//		}
	//
	//	}

	//---------------------VIEW ALL EMPLOYEE-----------------------------------------------------	
	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> empoyeeList = null;
		try {
			empoyeeList = employeeRepository.findAll();
		} catch (Exception e) {

			throw new BusinessException("EmployeeService-getAllEmployees-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeList.isEmpty()) {
			logger.warn("List IS Empty");
			throw new BusinessException("EmployeeService-getAllEmployees-1",
					" List is Empty, Add Some Data in Register Page... ");
		}
		return empoyeeList;

	}

	//---------------------VIEW 1 EMPLOYEE BY ID-----------------------------------------------------	
	@Override
	public Employee getEmployeeById(Long empId) {
		if (empId.equals(null)) {
			throw new BusinessException("EmployeeService-getEmployeeById-1",
					"You Entered a null value, please Enter Any int Value");
		}
		try {
			return employeeRepository.findById(empId).get();
		} catch (NoSuchElementException e) {
			throw new BusinessException("EmployeeService-getEmployeeById-BE-2",
					"Employee ID Not found in DataBase, Please enter valid ID " + e.getMessage());
		} catch (IllegalArgumentException e) {
			throw new BusinessException("EmployeeService-getEmployeeById-BE-3",
					"Something went wrong in service layer " + e.getMessage());
		}

	}

	//---------------------UPDATE 1 EMPLOYEE BY ID-----------------------------------------------------		
	@Override
	public Employee updateEmployee(Long empId, Employee employee) {

		logger.info("update Employee Method Working in Service Layer");
		if (employeeRepository.findById(empId).get().equals(null)) {
			logger.warn("Exception will be occured in Service Class" );
			throw new BusinessException("EmployeeService-updateEmployee-1",
					"Entered null value , Please Enter Valid ID");
		}

		Employee existingEmployee=employeeRepository.findById(empId).orElseThrow(()-> new BusinessException("Employee ID is not present in Database", "Please Enter valid ID"));

		existingEmployee.setFirstName(employee.getFirstName());
		existingEmployee.setLastName(employee.getLastName());
		existingEmployee.setDateOfBirth(employee.getDateOfBirth());
		existingEmployee.setEmail(employee.getEmail());
		int emailCount=0, phoneCount=0;

		if (phoneCount==2) {
			throw new BusinessException("AddEmployee Duplicate Phone","Entered Phone Number already exsists in DataBase");
		}
		if (!(employeeRepository.findByEmail(employee.getEmail())==null) ) {
			emailCount++;
		}
		existingEmployee.setPhone(employee.getPhone());
		if (!(employeeRepository.findByPhone(employee.getPhone())==null) ) {
			phoneCount++;
		}


		employeeRepository.save(existingEmployee);

		return existingEmployee;
	}	

	//---------------------DELETE 1 EMPLOYEE BY ID-----------------------------------------------------			
	@Override
	public Employee deleteEmployeeById(Long empId) {
		if (!employeeRepository.existsById(empId)) 
		{
			logger.warn("Inside the method: deleteEmployeeById,Employee id is not found"+empId);
			throw new BusinessException("EmployeeService-deleteEmployeeById-1",
					" Employee ID Not found in DataBase, Please enter valid ID");
		}
		Employee deletedEmp = employeeRepository.getById(empId);
		try {
			employeeRepository.deleteById(empId);
			logger.info("Inside the method: deleteEmployeeById,Employee Id is sucessfully deleted"+empId);
		} catch (NoSuchElementException e) {
			logger.warn("FileNotFound exception ocured");
			throw new BusinessException("EmployeeService-updateEmployee-2",
					"Employee ID Not found in DataBase, Please enter valid ID " + e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.warn("Inside the method: deleteEmployeeById ,IllegalArgumentException  ocured");
			throw new BusinessException("EmployeeService-updateEmployee-3",
					"Something went wrong in service layer " + e.getMessage());
		}
		return deletedEmp;
	}

	//---------------------LIST OF EMPLOYEES BY FIRST NAME-----------------------------------------------------	
	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) {

		List<Employee> empoyeeListByName = null;
		try {
			empoyeeListByName = employeeRepository.findByFirstName(firstName);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByFirstName-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeListByName.isEmpty()) {
			throw new BusinessException("EmployeeService-getEmployeeByFirstName-1",
					"Requested Data not found in List , Please enter some data in Register Page ");
		}
		return empoyeeListByName;
	}

	//---------------------LIST OF EMPLOYEES BY LAST NAME-----------------------------------------------------		
	@Override
	public List<Employee> getEmployeeByLastName(String lastName) {

		List<Employee> empoyeeListByName = null;
		try {
			empoyeeListByName = employeeRepository.findByLastName(lastName);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByLastName-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeListByName.isEmpty()) {
			throw new BusinessException("EmployeeService-getEmployeeByLastName-1",
					" Requested Data not found in List , Please enter some data in Register Page ");
		}
		return empoyeeListByName;
	}

	//---------------------VIEW 1 EMPLOYEE BY PHONE-----------------------------------------------------	
	@Override
	public Employee getEmployeeByPhone(Long phone) {
		Employee empoyeeListByPhone = null;
		try {
			empoyeeListByPhone = employeeRepository.findByPhone(phone);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByPhone-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (employeeRepository.existsById(empoyeeListByPhone.getEmpId())) {
			throw new BusinessException("EmployeeService-getEmployeeByPhone-1",
					"Requested Data not found in List , Please enter some data in Register Page  ");
		}
		return empoyeeListByPhone;

	}

	//---------------------VIEW 1 EMPLOYEE BY EMAIL-----------------------------------------------------	
	@Override
	public Employee getEmployeeByEmail(String email) {
		Employee empoyeeListByEmail = null;
		try {
			empoyeeListByEmail = employeeRepository.findByEmail(email);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByEmail-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (employeeRepository.existsById(empoyeeListByEmail.getEmpId())) {
			throw new BusinessException("EmployeeService-getEmployeeByEmail-1",
					"Requested Data not found in List , Please enter some data in Register Page  ");
		}
		return empoyeeListByEmail;
	}



	@Override
	public Optional<Employee> findById(Long id) {
		return employeeRepository.findById(id);
	}


}