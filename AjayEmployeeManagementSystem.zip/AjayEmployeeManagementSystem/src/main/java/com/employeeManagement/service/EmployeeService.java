package com.employeeManagement.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeManagement.custom.exception.BusinessException;
import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;

@Service
public class EmployeeService implements EmployeeServiceInterface {

	/*
	 * To Do : 
	 * 1 Duplicate Validation phone and email
	 * 2 
	 * 
	 */

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee employee) {

		if (employee.getFirstName().isEmpty() || employee.getFirstName().length() == 0) {
			throw new BusinessException("EmployeeService-addEmployee-1",
					"Entered Name is Null, Please Enter Valid Name...");
		}

		try {
			Employee savedEmployee =  employeeRepository.save(employee);
			savedEmployee.setEmpId("EST-"+savedEmployee.getId());
			savedEmployee = employeeRepository.save(employee);
			
			return savedEmployee;
		} catch (IllegalArgumentException e) {
			throw new BusinessException("EmployeeService-addEmployee-2",
					"Not Valid Name, Please Enter Valid Name " + e.getMessage());
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-addEmployee-3",
					"Something went wrong in service layer " + e.getMessage());
		}
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> empoyeeList = null;
		try {
			empoyeeList = employeeRepository.findAll();
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getAllEmployees-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeList.isEmpty()) {
			throw new BusinessException("EmployeeService-getAllEmployees-1",
					" List is Empty, Add Some Data in Register Page... ");
		}
		return empoyeeList;

	}

	@Override
	public Employee getEmployeeById(Long empId) {
		if (empId.equals(null)) {
			throw new BusinessException("EmployeeService-getEmployeeById-1",
					"You Entered a null value, please Enter Any int Value");
		}
		try {
			return employeeRepository.findById(empId).get();
		} catch (NoSuchElementException e) {
			throw new BusinessException("EmployeeService-getEmployeeById-BE-2",
					"Employee ID Not found in DataBase, Please enter valid ID " + e.getMessage());
		} catch (IllegalArgumentException e) {
			throw new BusinessException("EmployeeService-getEmployeeById-BE-3",
					"Something went wrong in service layer " + e.getMessage());
		}

	}

	@Override
	public Employee updateEmployee(Long id, Employee employee) {

		if (employeeRepository.findById(id).get().equals(null)) {
			throw new BusinessException("EmployeeService-updateEmployee-1",
					"Entered null value , Please Enter Valid ID");
		}
		
		
		try {
			Employee updatedEmployee = employeeRepository.findById(id).get();
		//	updatedEmployee.setEmpId(employee.getEmpId());
			updatedEmployee.setFirstName(employee.getFirstName());
			updatedEmployee.setLastName(employee.getLastName());
			updatedEmployee.setDateOfBirth(employee.getDateOfBirth());
			updatedEmployee.setEmail(employee.getEmail());
	        updatedEmployee.setPhone(employee.getPhone());
	        updatedEmployee.setPhotoPath(employee.getPhotoPath());
	        updatedEmployee= employeeRepository.save(updatedEmployee);
	        Employee	remp;
			if (updatedEmployee.getId()==id ) {
				remp= employeeRepository.save(updatedEmployee);
			}else if (!employeeRepository.existsById(id)) {
				throw new BusinessException("EmployeeService-updateEmployee-",
						"Employee ID Not found in DataBase, Please enter valid ID ");
			}
			else {
				throw new BusinessException("EmployeeService-updateEmployee-2",
						"ID, Miss Match");
			}
			return remp;
			
		} catch (NoSuchElementException e) {
			throw new BusinessException("EmployeeService-updateEmployee-",
					"Employee ID Not found in DataBase, Please enter valid ID " + e.getMessage());
		} catch (IllegalArgumentException e) {
			throw new BusinessException("EmployeeService-updateEmployee-1",
					"Something went wrong in service layer " + e.getMessage());
		}

	}

	@Override
	public void deleteEmployeeById(Long empId) {
		if (!employeeRepository.existsById(empId)) {
			throw new BusinessException("EmployeeService-deleteEmployeeById-1",
					" Employee ID Not found in DataBase, Please enter valid ID");
		}
		try {
			employeeRepository.deleteById(empId);
		} catch (NoSuchElementException e) {
			throw new BusinessException("EmployeeService-updateEmployee-2",
					"Employee ID Not found in DataBase, Please enter valid ID " + e.getMessage());
		} catch (IllegalArgumentException e) {
			throw new BusinessException("EmployeeService-updateEmployee-3",
					"Something went wrong in service layer " + e.getMessage());
		}

	}

	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) {

		List<Employee> empoyeeListByName = null;
		try {
			empoyeeListByName = employeeRepository.findByFirstName(firstName);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByFirstName-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeListByName.isEmpty()) {
			throw new BusinessException("EmployeeService-getEmployeeByFirstName-1",
					"Requested Data not found in List , Please enter some data in Register Page ");
		}
		return empoyeeListByName;
	}

	@Override
	public List<Employee> getEmployeeByLastName(String lastName) {

		List<Employee> empoyeeListByName = null;
		try {
			empoyeeListByName = employeeRepository.findByLastName(lastName);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByLastName-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeListByName.isEmpty()) {
			throw new BusinessException("EmployeeService-getEmployeeByLastName-1",
					" Requested Data not found in List , Please enter some data in Register Page ");
		}
		return empoyeeListByName;
	}

	@Override
	public List<Employee> getEmployeeByPhone(Long phone) {
		List<Employee> empoyeeListByPhone = null;
		try {
			empoyeeListByPhone = employeeRepository.findByPhone(phone);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByPhone-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeListByPhone.isEmpty()) {
			throw new BusinessException("EmployeeService-getEmployeeByPhone-1",
					"Requested Data not found in List , Please enter some data in Register Page  ");
		}
		return empoyeeListByPhone;

	}

	@Override
	public List<Employee> getEmployeeByEmail(String email) {
		List<Employee> empoyeeListByEmail = null;
		try {
			empoyeeListByEmail = employeeRepository.findByEmail(email);
		} catch (Exception e) {
			throw new BusinessException("EmployeeService-getEmployeeByEmail-2",
					"Something went wrong in service layer while fetching all employee details " + e.getMessage());
		}
		if (empoyeeListByEmail.isEmpty()) {
			throw new BusinessException("EmployeeService-getEmployeeByEmail-1",
					"Requested Data not found in List , Please enter some data in Register Page  ");
		}
		return empoyeeListByEmail;
	}

}
