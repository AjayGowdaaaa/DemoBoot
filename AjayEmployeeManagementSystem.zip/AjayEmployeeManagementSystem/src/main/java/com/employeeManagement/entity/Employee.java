package com.employeeManagement.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import lombok.Data;

/*
 * Creating a Employee class with respective attributes
 * Using Lombak so that it will generate Getter and Setter for all the attributes
 * Note - empid is a primary key
 */
@Data
@Entity
public class Employee {
	
	/*
	 * Instead of Long use AlphaNumerric
	 * EST-
	 * use of logger and save system date
	 * */
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long id;
	private String EmpId="EST - ";
	@NotNull 
	private String firstName; 
	private String lastName;
	/*
	 * Instead of date use String and put in a Util class
	 * */
	@Column(name="DOB")
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;
	@Email
	private String email;
	@NotNull
	private Long phone;
	/*
	 * save the Photo path/file
	 * */
	private String photoPath;
}
