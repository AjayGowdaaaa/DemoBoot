package com.employeeManagement;


import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;
import com.employeeManagement.service.EmployeeService;
@RunWith(SpringRunner.class)
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DataJpaTest
class EmployeeManagementSystemApplicationTests {
	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private EmployeeService employeeservice;

	@Test
	@Order(1)
	@Rollback(value = false)
	public void saveEmployeeTest() throws Exception {
		Employee employee=Employee.builder()
				.firstName("Shyam").lastName("prakesh").dateOfBirth("24/11/1995").email("Shyam@estuate")
				.phone(8977001549L).fileName("shyam.path").build();
		employeeservice.addEmployee(null, employee);
		Assertions.assertThat(employee.getEmpId()).isGreaterThan(0) ;


	}
	//	    @Test
	//	    @Order(2)
	//	    public void getemplopyee() {
	//	    	 Employee employee= employeeservice. getEmployeeById(1L);
	//	    	 Assertions.assertThat(employee.getEmpId()).isEqualTo(1L);
	//	    }
	//	    @Test
	//	    @Order(3)
	//	    public void getemplopyeebyList() {
	//	    	List< Employee> employee= employeeservice.getAllEmployees();
	//	    	 Assertions.assertThat(employee.size()).isEqualTo(0);
	//	    }
	//	    @Test
	//	    @Order(4)
	//	    @Rollback(value = false)
	//	    public void updateEmployeeTest() {
	//	    	Employee employee= employeeRepository.findById(1L).get();
	//	    	employee.setEmail("shyamPrakesh@gmail.com");
	//	    	Employee employeeupdated=employeeservice.updateEmployee(1L, employee);
	//	    	 Assertions.assertThat(employeeupdated.getEmail()).isEqualTo("shyamPrakesh@gmail.com");
	//	    	
	//	    }
	//	    @Test
	//	    @Order(5)
	//	    @Rollback(value = false)
	//	    public void deleteEmplopyeeTest() throws Exception{
	//	    	Employee employee= employeeRepository.findById(1L).get();
	//	    	employeeservice.deleteEmployeeById(1l);
	//	    	//ResultActions response = mockMvc.perform(delete("/delete", employee));
	//
	//	        // then - verify the output
	//	       // response.andExpect(status().isOk()).andDo(print());
	//	        Assertions.assertThat(employee.getEmpId()).isGreaterThan(0) ;       
	//	    }
}