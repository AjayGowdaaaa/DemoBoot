package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepo extends CrudRepository<Employee, Integer> {

	/*
	 * @Override default <S extends Employee> S save(S entity) { // TODO
	 * Auto-generated method stub System.out.println("inside emp repo"); return
	 * null; }
	 */
	

}
