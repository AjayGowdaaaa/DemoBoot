package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class EmpController {

	@Autowired
	EmployeeRepo repo;
	
	@RequestMapping("/")
	public String home() {
		System.out.println("Home method Running");
		return "home";
	}
	
	@RequestMapping("/addEmp")
	public String addEmployee(Employee  employee) {
		System.out.println("addEmployee method Running");
		repo.save(employee);
		return "home";
	}

}
